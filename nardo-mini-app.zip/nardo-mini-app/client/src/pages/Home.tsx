import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ShoppingBag, ShieldCheck, RefreshCw, ExternalLink, PackageOpen } from "lucide-react";
import { trpc } from "@/lib/trpc";

type TelegramWebApp = { ready?: () => void; expand?: () => void; initData?: string; initDataUnsafe?: { user?: { first_name?: string; username?: string } } };

declare global { interface Window { Telegram?: { WebApp?: TelegramWebApp } } }

const starterProducts = [
  { name: "كتالوج ناردو", category: "منتجات مختارة", price: "—", stock: "متاح" },
  { name: "أحدث العروض", category: "عروض المتجر", price: "—", stock: "متاح" },
];

export default function Home() {
  const [ready, setReady] = useState(false);
  const [name, setName] = useState("زائر ناردو");
  const [cart, setCart] = useState<any[]>([]);
  const [appUrl, setAppUrl] = useState("");
  const [version, setVersion] = useState("1.0.0");
  const [selectedProduct, setSelectedProduct] = useState<any | null>(null);
  const [merchantId, setMerchantId] = useState("");
  const bootstrap = trpc.telegram.bootstrap.useMutation({ onSuccess: (user) => { setName([user.first_name, user.last_name].filter(Boolean).join(" ") || user.username || "مستخدم ناردو"); setReady(true); } });
  const me = trpc.auth.me.useQuery(undefined, { enabled: ready, retry: false });
  const centralLink = trpc.settings.publicLink.useQuery(undefined, { retry: false });
  const telegramConfig = trpc.telegram.config.useQuery(undefined, { retry: false });
  const products = trpc.products.list.useQuery(undefined, { enabled: ready, retry: false });
  const orders = trpc.orders.mine.useQuery(undefined, { enabled: ready, retry: false });
  const createOrder = trpc.orders.create.useMutation({ onSuccess: () => { setCart([]); orders.refetch(); } });
  const saveSetting = trpc.settings.set.useMutation({ onSuccess: () => { centralLink.refetch(); } });
  const adminUsers = trpc.admin.users.useQuery(undefined, { enabled: me.data?.role === "admin", retry: false });
  const setUserRole = trpc.admin.setUserRole.useMutation({ onSuccess: () => adminUsers.refetch() });

  useEffect(() => {
    const webApp = window.Telegram?.WebApp;
    webApp?.ready?.();
    webApp?.expand?.();
    const initData = webApp?.initData;
    if (initData) bootstrap.mutate({ initData });
    else setReady(true);
  }, []);

  useEffect(() => { if (centralLink.data) setAppUrl(centralLink.data); }, [centralLink.data]);
  const shownProducts = products.data ?? [];
  const cartTotal = cart.reduce((sum, item) => sum + Number(item.price || 0), 0);

  return (
    <main dir="rtl" className="min-h-screen bg-[#f7f8fc] text-slate-900">
      <section className="mx-auto max-w-6xl px-4 pb-10 pt-5 sm:px-6">
        <header className="mb-8 flex items-center justify-between rounded-3xl bg-slate-950 px-5 py-4 text-white shadow-xl shadow-slate-900/10">
          <div className="flex items-center gap-3"><div className="rounded-2xl bg-orange-500 p-3"><ShoppingBag className="size-5" /></div><div><p className="text-xs text-slate-300">NARDO MINI APP</p><h1 className="text-lg font-bold">متجر ناردو</h1></div></div>
          <div className="flex items-center gap-2"><Badge className="border-0 bg-emerald-400/15 text-emerald-200"><ShieldCheck className="ml-1 size-3" /> جلسة آمنة</Badge>{me.data?.role === "admin" && <Badge className="border-0 bg-orange-400/20 text-orange-100">مدير</Badge>}{me.data?.role === "merchant" && <Badge className="border-0 bg-violet-400/20 text-violet-100">تاجر</Badge>}</div>
        </header>
        <div className="mb-7 grid gap-5 lg:grid-cols-[1.35fr_.65fr]">
          <div className="rounded-3xl bg-gradient-to-br from-orange-500 to-amber-400 p-7 text-white shadow-xl shadow-orange-500/20"><p className="mb-2 text-sm font-medium text-orange-50">مرحباً بك، {name}</p><h2 className="max-w-xl text-3xl font-black leading-tight sm:text-4xl">كل ما تحتاجه في متجر ناردو، داخل Telegram.</h2><p className="mt-4 max-w-lg text-sm leading-7 text-orange-50">واجهة سريعة ومريحة للمنتجات والمخزون والطلبات، مع صلاحيات واضحة لكل مستخدم.</p><div className="mt-6 flex flex-wrap gap-3"><Button className="bg-slate-950 text-white hover:bg-slate-800" onClick={() => document.getElementById("products")?.scrollIntoView({ behavior: "smooth" })}>تصفح المنتجات</Button><Button variant="outline" className="border-white/50 bg-transparent text-white hover:bg-white/10"><ExternalLink className="ml-2 size-4" /> مشاركة</Button></div></div>
          <Card className="rounded-3xl border-0 bg-white shadow-lg shadow-slate-900/5"><CardHeader><div className="flex items-center justify-between"><CardTitle className="text-base">حالة المتجر</CardTitle><span className="size-2.5 rounded-full bg-emerald-500" /></div></CardHeader><CardContent className="space-y-4 text-sm"><div className="flex items-center justify-between"><span className="text-slate-500">مصدر البيانات</span><strong>المربع المركزي</strong></div><div className="flex items-center justify-between"><span className="text-slate-500">الإصدار</span><strong>1.0.0</strong></div><div className="flex items-center justify-between gap-3"><span className="text-slate-500">الرابط المركزي</span>{centralLink.data ? <a className="max-w-[190px] truncate font-medium text-orange-600 underline" href={centralLink.data} target="_blank" rel="noreferrer">فتح التطبيق</a> : <span className="text-xs text-slate-400">يُضبط من المدير</span>}</div><div className="flex items-center justify-between"><span className="text-slate-500">الحالة</span><Badge className="bg-emerald-50 text-emerald-700 hover:bg-emerald-50">متصل</Badge></div><Button variant="outline" className="w-full" onClick={() => products.refetch()} disabled={products.isFetching}><RefreshCw className={`ml-2 size-4 ${products.isFetching ? "animate-spin" : ""}`} /> تحديث البيانات</Button></CardContent></Card>
        </div>
        <section id="products"><div className="mb-4 flex items-end justify-between"><div><p className="text-sm font-medium text-orange-600">الكتالوج</p><h2 className="text-2xl font-black">منتجات المتجر</h2></div><span className="text-sm text-slate-500">{shownProducts.length} عناصر</span></div>{products.isLoading ? <Card className="rounded-3xl border-0"><CardContent className="p-8 text-center text-slate-500">جاري تحميل المنتجات...</CardContent></Card> : products.isError ? <Card className="rounded-3xl border-0"><CardContent className="p-8 text-center text-red-600">تعذر تحميل المنتجات. اضغط تحديث البيانات وحاول مرة أخرى.</CardContent></Card> : shownProducts.length === 0 ? <Card className="rounded-3xl border-0"><CardContent className="p-8 text-center text-slate-500">لا توجد منتجات متاحة لهذا المتجر حالياً.</CardContent></Card> : <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{shownProducts.map((product: any, index: number) => <Card key={product.id ?? index} className="group rounded-3xl border-0 shadow-sm transition hover:-translate-y-1 hover:shadow-xl"><CardContent className="p-5"><div className="mb-5 flex h-32 items-center justify-center rounded-2xl bg-gradient-to-br from-slate-100 to-orange-50"><PackageOpen className="size-12 text-orange-500 transition group-hover:scale-110" /></div><div className="flex items-start justify-between gap-3"><div><button className="text-right font-bold hover:text-orange-600" onClick={() => setSelectedProduct(product)}>{product.name}</button><p className="mt-1 text-sm text-slate-500">{product.category ?? "منتجات ناردو"}</p></div><Badge variant="outline" className="border-emerald-200 text-emerald-700">{product.stock ?? product.stock === 0 ? `${product.stock} متاح` : product.stock}</Badge></div><div className="mt-5 flex items-center justify-between"><strong className="text-orange-600">{product.price ? `${product.price} دج` : "حسب المتجر"}</strong><Button size="sm" className="rounded-xl bg-slate-950 hover:bg-orange-600" onClick={() => setCart((current) => [...current, product])}>أضف للسلة</Button></div></CardContent></Card>)}</div>}</section>
        {me.data?.role === "admin" && <Card className="mt-8 rounded-3xl border-0 bg-slate-950 text-white shadow-xl"><CardHeader><CardTitle>لوحة المدير</CardTitle></CardHeader><CardContent className="grid gap-4 md:grid-cols-[1fr_140px_180px_auto]"><div><label className="mb-2 block text-xs text-slate-300">رابط Mini App</label><Input value={appUrl} onChange={(event) => setAppUrl(event.target.value)} placeholder="https://..." className="border-slate-700 bg-slate-900 text-white" /></div><div><label className="mb-2 block text-xs text-slate-300">معرف القناة</label><Input value={telegramConfig.data?.channelId ?? "غير مضبوط"} readOnly className="border-slate-700 bg-slate-900 text-slate-300" /></div><div><label className="mb-2 block text-xs text-slate-300">الإصدار</label><Input value={version} onChange={(event) => setVersion(event.target.value)} className="border-slate-700 bg-slate-900 text-white" /></div><Button className="self-end bg-orange-500 hover:bg-orange-600" disabled={!appUrl || saveSetting.isPending} onClick={() => { saveSetting.mutate({ key: "mini_app_url", value: appUrl }); saveSetting.mutate({ key: "app_version", value: version }); }}>حفظ الإعدادات</Button></CardContent></Card>}
        {me.data?.role === "admin" && <Card className="mt-8 rounded-3xl border-0 bg-white shadow-sm"><CardHeader><CardTitle>المستخدمون والأدوار</CardTitle></CardHeader><CardContent className="space-y-3"><div className="flex gap-2"><Input value={merchantId} onChange={(event) => setMerchantId(event.target.value)} placeholder="معرف متجر التاجر" /><span className="self-center text-xs text-slate-500">يُستخدم عند تعيين دور تاجر</span></div>{adminUsers.isLoading ? <p className="text-sm text-slate-500">جاري تحميل المستخدمين...</p> : adminUsers.data?.length ? adminUsers.data.map((person) => <div key={person.id} className="flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-slate-50 p-3 text-sm"><div><strong>{person.name || person.openId}</strong><p className="text-xs text-slate-500">{person.role}{person.merchantId ? ` · ${person.merchantId}` : ""}</p></div><div className="flex gap-2"><Button size="sm" variant="outline" onClick={() => setUserRole.mutate({ userId: person.id, role: "user" })}>مستخدم</Button><Button size="sm" variant="outline" onClick={() => setUserRole.mutate({ userId: person.id, role: "merchant", merchantId })}>تاجر</Button><Button size="sm" className="bg-slate-950" onClick={() => setUserRole.mutate({ userId: person.id, role: "admin" })}>مدير</Button></div></div>) : <p className="text-sm text-slate-500">لا يوجد مستخدمون بعد.</p>}</CardContent></Card>}
        <section className="mt-8 grid gap-5 lg:grid-cols-[.8fr_1.2fr]"><Card className="rounded-3xl border-0 shadow-sm"><CardHeader><CardTitle>سلة الطلب <Badge className="mr-2 bg-orange-100 text-orange-700 hover:bg-orange-100">{cart.length}</Badge></CardTitle></CardHeader><CardContent>{cart.length ? <><div className="space-y-2">{cart.map((item, index) => <div key={`${item.id ?? item.name}-${index}`} className="flex items-center justify-between rounded-xl bg-slate-50 p-3 text-sm"><span>{item.name}</span><span>{item.price || "—"} دج</span></div>)}</div><div className="mt-4 flex items-center justify-between border-t pt-4 font-bold"><span>الإجمالي</span><span className="text-orange-600">{cartTotal} دج</span></div><Button className="mt-4 w-full bg-orange-500 hover:bg-orange-600" disabled={createOrder.isPending} onClick={() => createOrder.mutate({ merchantId: cart[0]?.merchantId ?? "main", itemsJson: JSON.stringify(cart), total: String(cartTotal) })}>{createOrder.isPending ? "جاري الإرسال..." : "تأكيد الطلب"}</Button></> : <p className="py-4 text-sm text-slate-500">السلة فارغة. اختر منتجاً لإضافة طلب.</p>}</CardContent></Card><Card className="rounded-3xl border-0 shadow-sm"><CardHeader><CardTitle>طلباتي</CardTitle></CardHeader><CardContent>{orders.data?.length ? <div className="space-y-3">{orders.data.map((order) => <div key={order.id} className="flex items-center justify-between rounded-2xl bg-slate-50 p-4 text-sm"><div><strong>{order.orderKey}</strong><p className="mt-1 text-slate-500">{new Date(order.createdAt).toLocaleString("ar-DZ")}</p></div><Badge variant="outline">{order.status === "pending" ? "قيد المعالجة" : order.status}</Badge></div>)}</div> : <p className="py-4 text-sm text-slate-500">لا توجد طلبات بعد.</p>}</CardContent></Card></section>
        {selectedProduct && <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4" role="dialog" aria-modal="true"><Card className="w-full max-w-lg rounded-3xl border-0 shadow-2xl"><CardHeader><div className="flex items-center justify-between"><CardTitle>{selectedProduct.name}</CardTitle><Button variant="ghost" onClick={() => setSelectedProduct(null)}>إغلاق</Button></div></CardHeader><CardContent className="space-y-4"><div className="rounded-2xl bg-orange-50 p-5 text-center"><PackageOpen className="mx-auto size-16 text-orange-500" /></div><p className="leading-7 text-slate-600">{selectedProduct.description || "لا يوجد وصف إضافي لهذا المنتج."}</p><div className="flex items-center justify-between rounded-2xl bg-slate-50 p-4"><span>السعر</span><strong className="text-orange-600">{selectedProduct.price || "—"} دج</strong></div><Button className="w-full bg-orange-500 hover:bg-orange-600" onClick={() => { setCart((current) => [...current, selectedProduct]); setSelectedProduct(null); }}>أضف إلى السلة</Button></CardContent></Card></div>}
        <footer className="mt-10 border-t border-slate-200 pt-5 text-center text-xs text-slate-500">ناردو ميني آب · بياناتك محمية بجلسة Telegram</footer>
      </section>
    </main>
  );
}
