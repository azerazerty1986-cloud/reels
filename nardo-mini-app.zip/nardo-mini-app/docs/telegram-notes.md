# Telegram Mini App integration notes

المراجع الرسمية:

- https://core.telegram.org/bots/webapps — Telegram Mini Apps
- https://core.telegram.org/bots/api — Telegram Bot API

توضح وثائق Telegram أن Mini Apps تُفتح داخل Telegram كتطبيقات JavaScript، وأن بيانات `initData` يجب التحقق منها على الخادم قبل الاعتماد على هوية المستخدم. كما توضح Bot API أن `file_id` هو معرف يمكن إعادة استخدامه للملفات التي يتعامل معها البوت.

قرارات المشروع المبنية على ذلك:

- لا يظهر Bot Token في الواجهة؛ كل استدعاءات Bot API تتم من الخادم.
- يستخدم الخادم HMAC للتحقق من Telegram `initData` ثم ينشئ جلسة موقعة.
- تحفظ مراجع القناة مثل `channelId` و`messageId` و`fileId` ورقم الإصدار في قاعدة البيانات.
- المربع المركزي يحتفظ برابط Mini App فقط، بينما المتجر يعمل من رابط HTTPS مستضاف.
