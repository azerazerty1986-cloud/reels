export function shouldAcceptVersion(currentVersion: number, incomingVersion: number | null, versionAlreadySeen: boolean) {
  if (incomingVersion === null) return !versionAlreadySeen;
  if (versionAlreadySeen) return false;
  return incomingVersion >= currentVersion;
}
