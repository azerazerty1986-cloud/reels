import { and, desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, appSettings, orders, products, telegramMessages, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod", "merchantId", "telegramUserId"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function listProducts(merchantId?: string) {
  const db = await getDb();
  if (!db) return [];
  return merchantId
    ? db.select().from(products).where(and(eq(products.merchantId, merchantId), eq(products.active, true))).orderBy(desc(products.updatedAt))
    : db.select().from(products).where(eq(products.active, true)).orderBy(desc(products.updatedAt));
}

export async function upsertProduct(input: typeof products.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(products).values(input).onDuplicateKeyUpdate({
    set: {
      name: input.name,
      description: input.description,
      category: input.category,
      price: input.price,
      stock: input.stock,
      imageUrl: input.imageUrl,
      telegramMessageId: input.telegramMessageId,
      telegramFileId: input.telegramFileId,
      version: input.version,
      active: input.active,
    },
  });
}

export async function createOrder(input: typeof orders.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(orders).values(input);
}

export async function getSetting(key: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(appSettings).where(eq(appSettings.key, key)).limit(1);
  return result[0];
}

export async function setSetting(key: string, value: string, updatedBy?: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(appSettings).values({ key, value, updatedBy }).onDuplicateKeyUpdate({ set: { value, updatedBy } });
}

export async function telegramVersionExists(channelId: string, version: number) {
  const db = await getDb();
  if (!db) return false;
  const existing = await db.select({ id: telegramMessages.id }).from(telegramMessages)
    .where(and(eq(telegramMessages.channelId, channelId), eq(telegramMessages.version, version))).limit(1);
  return existing.length > 0;
}

export async function saveTelegramMessage(input: typeof telegramMessages.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const existing = await db.select({ id: telegramMessages.id }).from(telegramMessages)
    .where(and(eq(telegramMessages.channelId, input.channelId), eq(telegramMessages.messageId, input.messageId))).limit(1);
  if (existing.length) return false;
  await db.insert(telegramMessages).values(input);
  return true;
}

export async function listUsers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(users).orderBy(desc(users.createdAt));
}

export async function updateUserRole(userId: number, role: "user" | "admin" | "merchant", merchantId?: string | null) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(users).set({ role, merchantId: role === "merchant" ? merchantId ?? null : null }).where(eq(users.id, userId));
}

export async function listOrdersForUser(userId: number, merchantId?: string) {
  const db = await getDb();
  if (!db) return [];
  return merchantId
    ? db.select().from(orders).where(and(eq(orders.userId, userId), eq(orders.merchantId, merchantId))).orderBy(desc(orders.createdAt))
    : db.select().from(orders).where(eq(orders.userId, userId)).orderBy(desc(orders.createdAt));
}

