import crypto from "node:crypto";

const token = () => process.env.TELEGRAM_BOT_TOKEN;

export type TelegramWebAppUser = {
  id: number;
  first_name?: string;
  last_name?: string;
  username?: string;
  language_code?: string;
};

export function validateTelegramInitData(rawInitData: string, maxAgeSeconds = 86_400): TelegramWebAppUser {
  const botToken = token();
  if (!botToken) throw new Error("Telegram bot is not configured");
  const params = new URLSearchParams(rawInitData);
  const receivedHash = params.get("hash");
  if (!receivedHash) throw new Error("Telegram initData hash is missing");

  const authDate = Number(params.get("auth_date"));
  if (!Number.isFinite(authDate) || Math.floor(Date.now() / 1000) - authDate > maxAgeSeconds) {
    throw new Error("Telegram initData has expired");
  }

  params.delete("hash");
  const dataCheckString = Array.from(params.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([key, value]) => `${key}=${value}`)
    .join("\n");
  const secretKey = crypto.createHmac("sha256", "WebAppData").update(botToken).digest();
  const expectedHash = crypto.createHmac("sha256", secretKey).update(dataCheckString).digest("hex");
  const actual = Buffer.from(receivedHash, "hex");
  const expected = Buffer.from(expectedHash, "hex");
  if (actual.length !== expected.length || !crypto.timingSafeEqual(actual, expected)) {
    throw new Error("Telegram initData signature is invalid");
  }

  const user = JSON.parse(params.get("user") ?? "null") as TelegramWebAppUser | null;
  if (!user?.id) throw new Error("Telegram user is missing");
  return user;
}

export async function telegramApi<T>(method: string, body?: Record<string, unknown>): Promise<T> {
  const botToken = token();
  if (!botToken) throw new Error("Telegram bot is not configured");
  const response = await fetch(`https://api.telegram.org/bot${botToken}/${method}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body ?? {}),
  });
  const payload = (await response.json()) as { ok?: boolean; result?: T; description?: string };
  if (!response.ok || !payload.ok) throw new Error(payload.description ?? `Telegram ${method} failed`);
  return payload.result as T;
}

const SESSION_COOKIE = "nardo_telegram_session";

function encode(value: string) {
  return Buffer.from(value).toString("base64url");
}

function signature(value: string) {
  const secret = process.env.JWT_SECRET;
  if (!secret) throw new Error("JWT_SECRET is not configured");
  return crypto.createHmac("sha256", secret).update(value).digest("base64url");
}

export function createTelegramSession(userId: number) {
  const payload = encode(JSON.stringify({ userId, exp: Math.floor(Date.now() / 1000) + 60 * 60 * 24 * 7 }));
  return `${payload}.${signature(payload)}`;
}

export function verifyTelegramSession(value?: string) {
  if (!value) return null;
  const [payload, received] = value.split(".");
  if (!payload || !received || signature(payload) !== received) return null;
  try {
    const data = JSON.parse(Buffer.from(payload, "base64url").toString("utf8")) as { userId?: number; exp?: number };
    return data.userId && data.exp && data.exp > Math.floor(Date.now() / 1000) ? data.userId : null;
  } catch {
    return null;
  }
}

export function telegramSessionCookieName() {
  return SESSION_COOKIE;
}

export function telegramConfig() {
  return { channelId: process.env.TELEGRAM_CHANNEL_ID ?? null };
}
