import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function context(role: "user" | "admin" | "merchant"): TrpcContext {
  return {
    user: { id: 7, openId: "test", name: "Test", email: null, loginMethod: "test", role, merchantId: role === "merchant" ? "m-1" : null, telegramUserId: null, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
    req: {} as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("authorization boundaries", () => {
  it("rejects user access to admin user management", async () => {
    const caller = appRouter.createCaller(context("user"));
    await expect(caller.admin.users()).rejects.toThrow("Admin role required");
  });

  it("rejects regular users from product writes", async () => {
    const caller = appRouter.createCaller(context("user"));
    await expect(caller.products.upsert({ productKey: "p-1", merchantId: "m-1", name: "Test", price: "10", stock: 1 })).rejects.toThrow("Merchant or admin role required");
  });
});
