import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { createOrder, getSetting, getUserByOpenId, listOrdersForUser, listProducts, listUsers, saveTelegramMessage, setSetting, telegramVersionExists, updateUserRole, upsertProduct, upsertUser } from "./db";
import { createTelegramSession, telegramApi, telegramConfig, telegramSessionCookieName, validateTelegramInitData } from "./telegram";
import { shouldAcceptVersion } from "./sync";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  telegram: router({
    config: publicProcedure.query(() => telegramConfig()),
    bootstrap: publicProcedure.input(z.object({ initData: z.string().min(1) })).mutation(async ({ input, ctx }) => {
      const telegramUser = validateTelegramInitData(input.initData);
      const openId = `telegram:${telegramUser.id}`;
      await upsertUser({
        openId,
        telegramUserId: String(telegramUser.id),
        name: [telegramUser.first_name, telegramUser.last_name].filter(Boolean).join(" ") || telegramUser.username || null,
        loginMethod: "telegram-mini-app",
      });
      const storedUser = await getUserByOpenId(openId);
      if (!storedUser) throw new Error("Telegram user could not be created");
      ctx.res.cookie(telegramSessionCookieName(), createTelegramSession(storedUser.id), {
        httpOnly: true,
        secure: true,
        sameSite: "none",
        maxAge: 7 * 24 * 60 * 60 * 1000,
        path: "/",
      });
      return { ...telegramUser, role: storedUser.role, merchantId: storedUser.merchantId ?? null };
    }),
  }),
  products: router({
    list: protectedProcedure.input(z.object({ merchantId: z.string().optional() }).optional()).query(({ input, ctx }) =>
      listProducts(input?.merchantId ?? (ctx.user?.role === "merchant" ? (ctx.user.merchantId ?? "__missing_merchant__") : undefined)),
    ),
    upsert: protectedProcedure.input(z.object({
      productKey: z.string().min(1), merchantId: z.string().min(1), name: z.string().min(1),
      description: z.string().optional(), category: z.string().optional(), price: z.string(), stock: z.number().int().nonnegative(),
      imageUrl: z.string().url().optional(), telegramMessageId: z.string().optional(), telegramFileId: z.string().optional(), version: z.number().int().positive().optional(),
    })).mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin" && ctx.user.role !== "merchant") throw new Error("Merchant or admin role required");
      const merchantId = ctx.user.role === "merchant" ? (ctx.user.merchantId ?? "") : input.merchantId;
      if (!merchantId || (ctx.user.role === "merchant" && input.merchantId !== merchantId)) throw new Error("Invalid merchant scope");
      await upsertProduct({ ...input, merchantId, active: true });
      return { success: true };
    }),
  }),
  orders: router({
    mine: protectedProcedure.query(({ ctx }) => listOrdersForUser(ctx.user.id, ctx.user.role === "merchant" ? ctx.user.merchantId ?? undefined : undefined)),
    create: protectedProcedure.input(z.object({ merchantId: z.string().min(1), itemsJson: z.string().min(2), total: z.string() })).mutation(async ({ input, ctx }) => {
      const orderKey = `ORD-${Date.now()}-${ctx.user.id}`;
      await createOrder({ ...input, orderKey, userId: ctx.user.id, status: "pending" });
      try {
        await telegramApi("sendMessage", { chat_id: process.env.TELEGRAM_CHANNEL_ID, text: `🔔 طلب جديد\\n🆔 ${orderKey}\\n💰 الإجمالي: ${input.total} دج\\n📦 العناصر: ${input.itemsJson.slice(0, 800)}` });
      } catch (error) {
        console.warn("[Telegram] Order notification failed", error);
      }
      return { orderKey };
    }),
  }),
  admin: router({
    users: protectedProcedure.query(({ ctx }) => {
      if (ctx.user.role !== "admin") throw new Error("Admin role required");
      return listUsers();
    }),
    setUserRole: protectedProcedure.input(z.object({ userId: z.number().int().positive(), role: z.enum(["user", "admin", "merchant"]), merchantId: z.string().optional() })).mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin") throw new Error("Admin role required");
      await updateUserRole(input.userId, input.role, input.merchantId);
      return { success: true };
    }),
  }),
  sync: router({
    channel: protectedProcedure.input(z.object({ offset: z.number().int().nonnegative().optional() }).optional()).mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin") throw new Error("Admin role required");
      const storedOffset = Number((await getSetting("telegram_sync_offset"))?.value ?? 0);
      const offset = input?.offset ?? (Number.isFinite(storedOffset) ? storedOffset : 0);
      let updates: Array<{ update_id: number; channel_post?: { message_id: number; chat?: { id?: number }; text?: string; caption?: string; document?: { file_id: string } } }>;
      try {
        updates = await telegramApi<Array<{ update_id: number; channel_post?: { message_id: number; chat?: { id?: number }; text?: string; caption?: string; document?: { file_id: string } } }>>("getUpdates", { offset, limit: 50, timeout: 0, allowed_updates: ["channel_post"] });
      } catch (error) {
        await setSetting("telegram_sync_status", JSON.stringify({ status: "failed", message: error instanceof Error ? error.message : "Telegram API error", at: new Date().toISOString() }), ctx.user.id);
        throw error;
      }
      const storedVersion = Number((await getSetting("telegram_latest_version"))?.value ?? 0);
      let latestVersion = Number.isFinite(storedVersion) ? storedVersion : 0;
      let saved = 0;
      for (const update of updates) {
        const message = update.channel_post;
        if (!message || String(message.chat?.id ?? "") !== String(process.env.TELEGRAM_CHANNEL_ID ?? "")) continue;
        const caption = message.text ?? message.caption ?? "";
        const versionMatch = caption.match(/(?:الإصدار|version|v)\\s*[:#-]?\\s*(\\d+(?:\\.\\d+){0,2})/i);
        const numericVersion = versionMatch?.[1] ? Number(versionMatch[1].replace(/\\./g, "")) : null;
        const versionSeen = numericVersion !== null ? await telegramVersionExists(String(message.chat?.id), numericVersion) : false;
        if (!shouldAcceptVersion(latestVersion, numericVersion, versionSeen)) continue;
        const inserted = await saveTelegramMessage({ channelId: String(message.chat?.id), messageId: String(message.message_id), messageType: message.document ? "document" : "text", title: caption.split("\\n")[0]?.slice(0, 255), caption: caption || null, fileId: message.document?.file_id ?? null, payloadJson: JSON.stringify(message), version: numericVersion });
        if (inserted) saved += 1;
        if (numericVersion !== null && numericVersion > latestVersion) latestVersion = numericVersion;
      }
      const nextOffset = updates.length ? updates[updates.length - 1]!.update_id + 1 : offset;
      await setSetting("telegram_sync_offset", String(nextOffset), ctx.user.id);
      await setSetting("telegram_latest_version", String(latestVersion), ctx.user.id);
      await setSetting("telegram_last_sync", new Date().toISOString(), ctx.user.id);
      await setSetting("telegram_sync_status", JSON.stringify({ status: "ok", saved, nextOffset, version: latestVersion, at: new Date().toISOString() }), ctx.user.id);
      return { saved, nextOffset, version: latestVersion };
    }),
  }),
  settings: router({
    publicLink: publicProcedure.query(async () => (await getSetting("mini_app_url"))?.value ?? null),
    get: protectedProcedure.input(z.object({ key: z.string().min(1) })).query(({ input }) => getSetting(input.key)),
    set: protectedProcedure.input(z.object({ key: z.string().min(1), value: z.string().min(1) })).mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin") throw new Error("Admin role required");
      await setSetting(input.key, input.value, ctx.user.id);
      if (input.key === "app_version") {
        try { await telegramApi("sendMessage", { chat_id: process.env.TELEGRAM_CHANNEL_ID, text: `🚀 تحديث Nardo Mini App\\n📌 الإصدار: ${input.value}` }); } catch (error) { console.warn("[Telegram] Version notification failed", error); }
      }
      return { success: true };
    }),
  }),
});

export type AppRouter = typeof appRouter;
