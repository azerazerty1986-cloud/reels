import { describe, expect, it } from "vitest";

describe("Telegram credentials", () => {
  it("validates TELEGRAM_BOT_TOKEN with Telegram getMe", async () => {
    const token = process.env.TELEGRAM_BOT_TOKEN;
    if (!token) {
      throw new Error("TELEGRAM_BOT_TOKEN is required to validate Telegram integration");
    }

    const response = await fetch(`https://api.telegram.org/bot${token}/getMe`);
    const payload = (await response.json()) as { ok?: boolean; description?: string };

    expect(response.ok).toBe(true);
    expect(payload.ok).toBe(true);

    const channelId = process.env.TELEGRAM_CHANNEL_ID;
    if (!channelId) {
      throw new Error("TELEGRAM_CHANNEL_ID is required to validate channel access");
    }

    const channelResponse = await fetch(
      `https://api.telegram.org/bot${token}/getChat?chat_id=${encodeURIComponent(channelId)}`,
    );
    const channelPayload = (await channelResponse.json()) as {
      ok?: boolean;
      result?: { id?: number | string };
    };

    expect(channelResponse.ok).toBe(true);
    expect(channelPayload.ok).toBe(true);
    expect(String(channelPayload.result?.id)).toBe(String(channelId));
  }, 15_000);
});
