import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import { sdk } from "./sdk";
import { getUserByOpenId } from "../db";
import { telegramSessionCookieName, verifyTelegramSession } from "../telegram";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
};

export async function createContext(
  opts: CreateExpressContextOptions
): Promise<TrpcContext> {
  let user: User | null = null;

  try {
    user = await sdk.authenticateRequest(opts.req);
  } catch (error) {
    user = null;
  }

  if (!user) {
    const cookies = opts.req.headers.cookie ?? "";
    const session = cookies.split(";").map((part) => part.trim()).find((part) => part.startsWith(`${telegramSessionCookieName()}=`))?.split("=").slice(1).join("=");
    const telegramUserId = verifyTelegramSession(session);
    if (telegramUserId) user = await getUserByOpenId(`telegram:${telegramUserId}`) ?? null;
  }

  return {
    req: opts.req,
    res: opts.res,
    user,
  };
}
