import { describe, expect, it } from "vitest";
import { shouldAcceptVersion } from "./sync";

describe("Telegram sync version policy", () => {
  it("accepts a newer or equal unseen version", () => {
    expect(shouldAcceptVersion(100, 101, false)).toBe(true);
    expect(shouldAcceptVersion(100, 100, false)).toBe(true);
  });

  it("rejects duplicate and older versions", () => {
    expect(shouldAcceptVersion(100, 100, true)).toBe(false);
    expect(shouldAcceptVersion(100, 99, false)).toBe(false);
  });
});
