import crypto from "node:crypto";
import { describe, expect, it } from "vitest";
import { createTelegramSession, validateTelegramInitData, verifyTelegramSession } from "./telegram";

function makeInitData(userId: number) {
  const token = process.env.TELEGRAM_BOT_TOKEN!;
  const params = new URLSearchParams({
    auth_date: String(Math.floor(Date.now() / 1000)),
    user: JSON.stringify({ id: userId, first_name: "Nardo" }),
  });
  const data = [...params.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => `${k}=${v}`).join("\n");
  const secret = crypto.createHmac("sha256", "WebAppData").update(token).digest();
  params.set("hash", crypto.createHmac("sha256", secret).update(data).digest("hex"));
  return params.toString();
}

describe("Telegram Mini App security", () => {
  it("validates signed initData and rejects tampering", () => {
    const raw = makeInitData(12345);
    expect(validateTelegramInitData(raw).id).toBe(12345);
    const tampered = raw.replace("12345", "12346");
    expect(() => validateTelegramInitData(tampered)).toThrow();
  });

  it("round-trips a signed server session and rejects modification", () => {
    process.env.JWT_SECRET = process.env.JWT_SECRET || "test-secret";
    const session = createTelegramSession(42);
    expect(verifyTelegramSession(session)).toBe(42);
    expect(verifyTelegramSession(`${session}x`)).toBeNull();
  });
});
