CREATE TABLE `appSettings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`key` varchar(128) NOT NULL,
	`value` text NOT NULL,
	`updatedBy` int,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `appSettings_id` PRIMARY KEY(`id`),
	CONSTRAINT `appSettings_key_unique` UNIQUE(`key`)
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orderKey` varchar(128) NOT NULL,
	`userId` int,
	`merchantId` varchar(128) NOT NULL,
	`status` enum('pending','accepted','delivered','cancelled') NOT NULL DEFAULT 'pending',
	`itemsJson` text NOT NULL,
	`total` decimal(12,2) NOT NULL,
	`telegramMessageId` varchar(64),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `orders_id` PRIMARY KEY(`id`),
	CONSTRAINT `orders_orderKey_unique` UNIQUE(`orderKey`)
);
--> statement-breakpoint
CREATE TABLE `products` (
	`id` int AUTO_INCREMENT NOT NULL,
	`productKey` varchar(128) NOT NULL,
	`merchantId` varchar(128) NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`category` varchar(128),
	`price` decimal(12,2) NOT NULL,
	`stock` int NOT NULL DEFAULT 0,
	`imageUrl` text,
	`telegramMessageId` varchar(64),
	`telegramFileId` varchar(256),
	`version` int NOT NULL DEFAULT 1,
	`active` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `products_id` PRIMARY KEY(`id`),
	CONSTRAINT `products_productKey_unique` UNIQUE(`productKey`)
);
--> statement-breakpoint
CREATE TABLE `telegramMessages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`channelId` varchar(64) NOT NULL,
	`messageId` varchar(64) NOT NULL,
	`messageType` varchar(64) NOT NULL,
	`title` varchar(255),
	`caption` text,
	`fileId` varchar(256),
	`version` int,
	`payloadJson` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `telegramMessages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','admin','merchant') NOT NULL DEFAULT 'user';--> statement-breakpoint
ALTER TABLE `users` ADD `merchantId` varchar(128);--> statement-breakpoint
ALTER TABLE `users` ADD `telegramUserId` varchar(64);--> statement-breakpoint
ALTER TABLE `users` ADD CONSTRAINT `users_telegramUserId_unique` UNIQUE(`telegramUserId`);