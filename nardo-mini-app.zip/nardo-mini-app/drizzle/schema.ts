import { boolean, decimal, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin", "merchant"]).default("user").notNull(),
  merchantId: varchar("merchantId", { length: 128 }),
  telegramUserId: varchar("telegramUserId", { length: 64 }).unique(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const products = mysqlTable("products", {
  id: int("id").autoincrement().primaryKey(),
  productKey: varchar("productKey", { length: 128 }).notNull().unique(),
  merchantId: varchar("merchantId", { length: 128 }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  category: varchar("category", { length: 128 }),
  price: decimal("price", { precision: 12, scale: 2 }).notNull(),
  stock: int("stock").default(0).notNull(),
  imageUrl: text("imageUrl"),
  telegramMessageId: varchar("telegramMessageId", { length: 64 }),
  telegramFileId: varchar("telegramFileId", { length: 256 }),
  version: int("version").default(1).notNull(),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const orders = mysqlTable("orders", {
  id: int("id").autoincrement().primaryKey(),
  orderKey: varchar("orderKey", { length: 128 }).notNull().unique(),
  userId: int("userId"),
  merchantId: varchar("merchantId", { length: 128 }).notNull(),
  status: mysqlEnum("status", ["pending", "accepted", "delivered", "cancelled"]).default("pending").notNull(),
  itemsJson: text("itemsJson").notNull(),
  total: decimal("total", { precision: 12, scale: 2 }).notNull(),
  telegramMessageId: varchar("telegramMessageId", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const telegramMessages = mysqlTable("telegramMessages", {
  id: int("id").autoincrement().primaryKey(),
  channelId: varchar("channelId", { length: 64 }).notNull(),
  messageId: varchar("messageId", { length: 64 }).notNull(),
  messageType: varchar("messageType", { length: 64 }).notNull(),
  title: varchar("title", { length: 255 }),
  caption: text("caption"),
  fileId: varchar("fileId", { length: 256 }),
  version: int("version"),
  payloadJson: text("payloadJson"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const appSettings = mysqlTable("appSettings", {
  id: int("id").autoincrement().primaryKey(),
  key: varchar("key", { length: 128 }).notNull().unique(),
  value: text("value").notNull(),
  updatedBy: int("updatedBy"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Product = typeof products.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type TelegramMessage = typeof telegramMessages.$inferSelect;
export type AppSetting = typeof appSettings.$inferSelect;

// TODO: Add your tables here